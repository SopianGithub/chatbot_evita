<template>
  <VbDemo>
    <VbCard title="Position" width="100%">
      <AppNavbar />
    </VbCard>
  </VbDemo>
</template>

<script>
import AppNavbar from './AppNavbar'

export default {
  components: { AppNavbar },
}
</script>
