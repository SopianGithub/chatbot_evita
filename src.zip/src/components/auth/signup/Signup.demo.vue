<template>
  <VbDemo>
    <VbCard dashed no-padding>
      <Signup style="width: 500px;"/>
    </VbCard>
  </VbDemo>
</template>

<script>
import Signup from './Signup.vue'

export default {
  components: {
    Signup,
  },
}
</script>
