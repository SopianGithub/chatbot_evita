<template>
  <div>
  	<data-am class="mb-4"/>
  </div>
 </template>

 <script>
 	import DataAm from './DataAm';

 	export default {
	  components: {
	    DataAm,
	  },
	}
 </script>

<style lang="scss">
</style>