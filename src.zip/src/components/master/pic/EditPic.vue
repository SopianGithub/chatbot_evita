<template>
  <div class="form-elements">
    <div class="row">
      <div class="flex xs12">
        <va-card :title="$t('forms.inputs.title')">
          <div class="mb-3" v-if="isSuccess">
            <va-notification closeable>
              <va-badge>
                {{ $t('notificationsPage.notifications.success') }}
              </va-badge>
              {{ messageNotif }}
            </va-notification>
          </div>
          <div class="mb-3" v-if="!savingSuccessful">
            <va-notification color="danger" closeable @click="removeNotif">
              <va-badge color="danger" >
                {{ $t('notificationsPage.notifications.danger') }}
              </va-badge>
                {{ messageNotif }}
            </va-notification>
          </div>
          <form @submit.prevent="onsubmit" >
            <div class="row">
              <div class="flex md12 sm12 xs12">
                <va-input
                  v-model="nik"
                  type="number"
                  readonly
                  placeholder="Input NIK PIC"
                >
                  <va-icon
                    slot="prepend"  
                    color="gray"
                    name="fa fa-bookmark"
                  />
                </va-input>
              </div>
              <div class="flex md12 sm12 xs12">
                <va-input
                  v-model="nama"
                  placeholder="Input Nama PIC"
                >
                  <va-icon
                    slot="prepend"
                    color="gray"
                    name="fa fa-user"
                  />
                </va-input>
              </div>
              <div class="flex md12 sm12 xs12">
                <va-input
                  v-model="mobile"
                  type="number"
                  placeholder="Input Nama No HP PIC"
                >
                  <va-icon
                    slot="prepend"
                    color="gray"
                    name="fa fa-phone"
                  />
                </va-input>
              </div>
              <div class="flex md12 sm12 xs12">
                <treeselect v-model="divisi" :multiple="false" :options="optionsPIC" />
              </div>
              <div class="flex md12 sm12 xs12">
                <va-input
                  v-model="title"
                  placeholder="Input Title PIC"
                >
                  <va-icon
                    slot="prepend"
                    color="gray"
                    name="fa fa-id-card"
                  />
                </va-input>
              </div>
              <div class="flex md12 sm12 xs12">
                <va-select
                  v-model="bptype"
                  label="Band Type"
                  :options="bpOpt"
                  noClear
                />
              </div>
              <div class="flex md12 sm12 xs12">
                <label class="typo__label">Nama Alias Unit/PIC</label>
                <multiselect v-model="aliasValue" tag-placeholder="Add Alias Name Of PIC" placeholder="Input Alias PIC" label="name" track-by="code" :options="optionsAlias" :multiple="true" :taggable="true" @tag="addTag" @remove="toggleUnSelectAliasPIC"></multiselect>
              </div>
              <div class="flex">
                <va-button
                   type="submit" 
                   class="my-0"  
                  > 
                  Edit PIC</va-button>
              </div>  
            </div>
          </form>
        </va-card>
      </div>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'form-elements',
  data () {
    return {
      nik: '',
      nama: '',
      mobile: '',
      isMale: true,
      savingSuccessful: true,
      messageNotif: '',
      isSuccess: false,
      divisi: null,
      title: null,
      bptype: null,
      bpOpt : ['I', 'II', 'III', 'IV', 'V', 'VI'],
      optionsPIC: [],
      aliasValue: [
        { name: 'Input Alias', code: 'xxxxx' }
      ],
      optionsAlias: [],
      idloker: null,
    }
  },
  created() {
    this.getLoker()
    this.loadPic()
  },
  methods: {
    clear (field) {
      this[field] = ''
    },
    oninput() {
      this.savingSuccessful = false
      if(this.nik !== '' && this.name !== '' && this.mobile !== '')
        this.savingSuccessful = true
    },
    getLoker(){
      axios.get('http://localhost:5000/employe/loker')
        .then(response => {
          this.optionsPIC = response.data.values
        })
    },
    loadPic() {
      this.nik = this.$route.params.nik
      let dataEdit = []
      axios.get(`http://localhost:5000/employe/${this.nik}`)
        .then( res => {
          if(res.status === 200){
            this.nama = res.data.values.name
            this.mobile = res.data.values.mobile
            this.divisi = res.data.values.loker_select
            this.bptype = res.data.values.loker.bp
            this.title = res.data.values.loker.title
            this.idloker = res.data.values.loker.id
            let arr_alias = res.data.values.loker.alias
            for (var i = 0; i < arr_alias.length; i++) {
              this.aliasValue.push({
                name: arr_alias[i], code: this.makeid(5) 
              })
            }
            this.optionsAlias = this.aliasValue
          }else{
            this.messageNotif = `Terjadi Kesalahan Pada Proses Penyimpanan Data`
          }
        })
    },
    async onsubmit() {
      let arr_div = this.divisi.split("||")
      let tmploker = {
          bp: this.bptype,
          title: this.title,
          divisi: arr_div[0],
          unit: (arr_div[2] != '') ? arr_div[2] : arr_div[0],
          sub_unit: (arr_div[3] != '') ? arr_div[3] : arr_div[0],
          alias: this.optionsAlias.map(function(index, elem) {
            return index['name'];
          })
      }
      let params = {
        name: this.nama,
        mobile: this.mobile,
        loker: tmploker
      }
      console.log(params)
      if(this.nik !== '' && this.name !== '' && this.mobile !== ''){
        await axios.put(`http://localhost:5000/employe/${this.nik}`, params)
          .then((res) => {
            if(res.status === 200){
              this.messageNotif = `Input Data PIC Berhasil`
              this.isSuccess = true
              this.savingSuccessful = true
              setTimeout(() => {
                this.$router.push({ path : '/admin/master/pic' })
              }, 1000)
            }else{
              this.messageNotif = `Terjadi Kesalahan Pada Proses Penyimpanan Data`
            }
          })
      }else{
        this.savingSuccessful = false
        this.isSuccess = false
        this.messageNotif = `Harap Diisi Semua Inputan`
      }
    },
    removeNotif(){
      this.savingSuccessful = true
    },
    addTag (newTag) {
      const tag = {
        name: newTag,
        code: newTag.substring(0, 2) + Math.floor((Math.random() * 10000000))
      }
      this.optionsAlias.push(tag)
      this.aliasValue.push(tag)
    },
    toggleUnSelectAliasPIC({ name, code }){
      this.optionsAlias = this.optionsAlias.filter(function(index) {
        return index['name'] != name
      });
      this.aliasValue = this.optionsAlias
    },
    makeid(length) {
      var result           = '';
      var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;
      for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }
      return result;
    }
  },
}
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style>
  .row.row-inside {
    max-width: none;
  }
</style>
