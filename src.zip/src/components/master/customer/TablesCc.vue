<template>
  <div>
  	<data-cc class="mb-4"/>
  </div>
 </template>

 <script>
 	import DataCc from './DataCc';

 	export default {
	  components: {
	    DataCc,
	  },
	}
 </script>

<style lang="scss">
</style>