<template>
  <VbDemo>
    <VbCard tutle="default">
      <color-presentation />
    </VbCard>
  </VbDemo>
</template>

<script>
import ColorPresentation from './ColorPresentation'

export default {
  components: {
    ColorPresentation,
  },
}
</script>
