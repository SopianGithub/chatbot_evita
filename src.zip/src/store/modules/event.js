import Vue from 'vue';
export const EventQuery = new Vue();